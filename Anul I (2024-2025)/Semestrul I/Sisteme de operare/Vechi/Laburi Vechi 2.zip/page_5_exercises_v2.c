// exercise 1
// Write a C program which allocates a zone of virtual memory with only read only rights. Create a pointer to an address in the read only zone you just created and try to write at that address. Find in the handler registered to handle SIGSEGV signal the address where the access violation was produced and change the rights on the page with mprotect function.
#include <stdio.h>
#include <sys/mman.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
void sigsegv_handler(int signal, siginfo_t* siginfo, void* uap) {
	/* actions that should be taken when the signal is received */
	printf("Attempt to access memory at address %p\n", siginfo->si_addr);
	mprotect(siginfo->si_addr,4096,PROT_READ | PROT_WRITE);
}
int main(){
	int *ptr = mmap ( NULL, 4096, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, 0, 0);

	struct sigaction act;
	memset(&act, 0, sizeof(struct sigaction));
	act.sa_flags   = SA_SIGINFO;
	act.sa_sigaction = sigsegv_handler;
	sigaction(SIGSEGV, &act, NULL);

	ptr[0]=10;
	printf("it worked\n");
	ptr[0]=10;

	int err = munmap(ptr, 4096);
	return 0;
}

// exercise 2
// According to POSIX.1, a process-directed signal (sent using kill(2), for example) should be handled by a single, arbitrarily selected thread within the process, so which thread in the process will handle this signal is undetermined.
// If the signal is related to a hardware fault or expiring timer, the signal is sent to the thread whose action caused the event. Other signals, on the other hand, are delivered to an arbitrary thread.
