// Create a loop in your program, to prevent it from ending.
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
int main(void) 
{
	pid_t pid = getpid();
	printf("pid: %d\n", pid);
	int i = 0;
	while(1)
	{
		i = (i + 1) % 2;
	}
	return 0;
}
/*
oanac@OanaC:~/Documents$ cat /proc/5243/maps
5624cad25000-5624cad26000 r-xp 00000000 08:06 3014958                    /home/oanac/Documents/infinite
5624caf25000-5624caf26000 r--p 00000000 08:06 3014958                    /home/oanac/Documents/infinite
5624caf26000-5624caf27000 rw-p 00001000 08:06 3014958                    /home/oanac/Documents/infinite
5624ccec1000-5624ccee2000 rw-p 00000000 00:00 0                          [heap]
7f137d0d7000-7f137d2be000 r-xp 00000000 08:06 4199581                    /lib/x86_64-linux-gnu/libc-2.27.so
7f137d2be000-7f137d4be000 ---p 001e7000 08:06 4199581                    /lib/x86_64-linux-gnu/libc-2.27.so
7f137d4be000-7f137d4c2000 r--p 001e7000 08:06 4199581                    /lib/x86_64-linux-gnu/libc-2.27.so
7f137d4c2000-7f137d4c4000 rw-p 001eb000 08:06 4199581                    /lib/x86_64-linux-gnu/libc-2.27.so
7f137d4c4000-7f137d4c8000 rw-p 00000000 00:00 0 
7f137d4c8000-7f137d4f1000 r-xp 00000000 08:06 4194510                    /lib/x86_64-linux-gnu/ld-2.27.so
7f137d6d8000-7f137d6da000 rw-p 00000000 00:00 0 
7f137d6f1000-7f137d6f2000 r--p 00029000 08:06 4194510                    /lib/x86_64-linux-gnu/ld-2.27.so
7f137d6f2000-7f137d6f3000 rw-p 0002a000 08:06 4194510                    /lib/x86_64-linux-gnu/ld-2.27.so
7f137d6f3000-7f137d6f4000 rw-p 00000000 00:00 0 
7ffe434f2000-7ffe43513000 rw-p 00000000 00:00 0                          [stack]
7ffe43524000-7ffe43527000 r--p 00000000 00:00 0                          [vvar]
7ffe43527000-7ffe43529000 r-xp 00000000 00:00 0                          [vdso]
ffffffffff600000-ffffffffff601000 r-xp 00000000 00:00 0                  [vsyscall]
cat: –: No such file or directory 
The heap was mapped at 5624ccec1000-5624ccee2000, and the stack was mapped at 7ffe434f2000-7ffe43513000;
The location of the program and the libraries I used were also mapped.
*/
/*
oanac@OanaC:~/Documents$ ldd infinite
	linux-vdso.so.1 (0x00007ffc97ff2000)
	libc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x00007f17abdcf000)
	/lib64/ld-linux-x86-64.so.2 (0x00007f17ac3c2000)
oanac@OanaC:~/Documents$ 
I can observe the fact that only one library was mapped.
Apart from the fact that one of the libraries was mapped in both situations, there's no other relation between the two, they are different "processes", so they have different "addresses".*/


