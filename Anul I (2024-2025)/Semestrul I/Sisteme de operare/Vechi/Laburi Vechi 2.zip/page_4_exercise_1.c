// Write a C program, which prints to console "Hello World!"
#include <stdio.h>
int main(void) 
{
	printf("Hello World!\n");
	return 0;
}
// "Compile it!": gcc page_4_exercise_1.c -o hello_world
// Run objdump -h executable_name: objdump -h hello_world
// and identify the zones described above: text/code zone; data zone.
// Find the stack zone and the heap zone: These zones don't exist, because we don't have any stack frames and we didn't allocate anything dynamically.
// Identify the addresses from where each zone starts: 
// 1. Text/code zone: 0000000000000238;
// 2. Data zone: 
// 2.1 .data: 0000000000201000;
// 2.2 .bss: 0000000000201010.
